#solucionador de sudoku con forward checking
#para cambiar el board que se quiere leer cambiar al nombre
#deseado en la linea 163, para deshabilitar verbose en la 162.
#Los archivos de tablero se encuentran en la carpeta boards.
#todos de dificultad imposible.
#autores:
#Nicolas López Hernandez- 1088238419
#Jorge Luis López Grajales- 1037580544

#Se importa la biblioteca os para el manejo de archivos.
import os
import copy
columnas = "ABCDEFGHI"
filas = {i for i in range(1, 10)}

#inicializa los valores donde se iteran letras con numeros dando A1 hasta I9.
def inicializar_valores():
    valores = {}
    for col in columnas:
        for fil in filas:
            valores[f"{col}{fil}"] = filas.copy()
    return valores

#crean las restricciones del tablero por filas columnas y subcuadros de 3x3.
def crear_restricciones():
    restricciones = []
    # Revisión columnas en filas, se itera (A1 A2 A3... B1 B2....)
    for col in columnas:
        valores_set = set()
        for fil in filas:
            valores_set.add(f"{col}{fil}")
        restricciones.append(valores_set)

    # Revisión filas en columnas, se itera (A1 B1 C1... A2 B2 C2)
    for fil in filas:
        valores_set = set()
        for col in columnas:
            valores_set.add(f"{col}{fil}")
        restricciones.append(valores_set)

    # Creación de restricciones para los recuadros 3x3
    for i in range(3):
        for j in range(3):
            valores_set = set()
            # Calcular la posición inicial del recuadro
            for k in range(3):
                for l in range(3):
                    fila = i * 3 + k + 1
                    columna = chr(j * 3 + l + ord('A')) 
                    valores_set.add(f"{columna}{fila}") # Agregar la celda al conjunto
            restricciones.append(valores_set)

    return restricciones

#carga el archivo de los valores del tablero y asigna los valores a cada iteracion
def cargar_tablero(valores, archivo):
    filePath = os.path.join(os.path.dirname(__file__), 'boards', archivo)
    print(f"Loading board from: {filePath}")  # Mensaje de depuración.
    if not os.path.isfile(filePath):
        print(f"File not found: {filePath}")
        return False #Si no carga devuelve false.
    with open(filePath) as fd:
        for fil in filas:
            for col in columnas:
                value = int(fd.readline().strip())
                if value < 10:
                    valores[f"{col}{fil}"] = {value}
    return True #Si carga devueve true.

#aplicacion de restricciones al tablero cargado
def aplicar_restricciones(valores, restricciones, verbose=False):
    if verbose:
      print("[INFO] Aplicando restricciones")

    valores_copy = {k: v.copy() for k, v in valores.items()}#copia los valores para restaurarlos en caso de fallar
    any_change = True
    while any_change:
        any_change = False
        for cons in restricciones:#Se itera con cada conjunto de restricciones.
            for key in cons:#Se verifican las celdas con valor de longitud 1.
                if len(valores[key]) == 1:
                    value = list(valores[key])[0]
                    if verbose:
                      print(f"[INFO] celda{key} se ha fijado en el valor {value}")
                    for keydeleted in cons:#elimina valores de celdas
                        if keydeleted != key and value in valores[keydeleted]:
                            if verbose:
                              print(f"[INFO] Eliminando valor {value} de la celda {keydeleted}")
                            valores[keydeleted].discard(value)
                            if len(valores[keydeleted]) == 0:
                                if verbose:
                                  print(f"[INFO] Inconsistencia encontrada en la celda {keydeleted}. Restaurando valores...")
                                # Restaurar valores originales y retornar False
                                valores.update(valores_copy)
                                return False
                            any_change = True #Registra los cambios hechos.
    return True

#imprime el tablero
def imprimir_tablero(valores):
    for fil in filas:
        print(' '.join(str(list(valores[f"{col}{fil}"])[0]) if len(valores[f"{col}{fil}"]) == 1 else '.' for col in columnas))

#funcion de busqueda(variacion de backtraking).
def forward_checking(valores, restricciones, verbose=False):
    soluciones = []

    #esta funcion busca la siguiente casilla con menos longitud.
    def seleccionar_variable(valores):
        min_len = float('inf')
        min_var = None
        for key in valores:
            if 1 < len(valores[key]) < min_len:
                min_len = len(valores[key])
                min_var = key
        return min_var

    #Verifica si es consistente el valor revisandolo en filas, columnas y subcuadros.
    def es_consistente(valores, restricciones):
        for cons in restricciones:
            seen = set()
            for key in cons:
                if len(valores[key]) == 1:
                    value = list(valores[key])[0]
                    if value in seen:
                        return False
                    seen.add(value)
        return True

    #busca celdas no asignadas y prueba asignarle valores de su dominio.
    def forward_check(valores, restricciones):
        variable = seleccionar_variable(valores)
        if variable is None:
            if verbose:
              print("[INFO] Solucion encontrada")
            soluciones.append({k: v.copy() for k, v in valores.items()})
            return False  # Continuar buscando otras soluciones

        dominio_original = valores[variable].copy()
        for valor in dominio_original:
            valores[variable] = {valor}
            if verbose:
               print(f"[INFO] Intentando asignar {valor} a la celda {variable}")
            if es_consistente(valores, restricciones):
                valores_copia = {k: v.copy() for k, v in valores.items()}
                if aplicar_restricciones(valores_copia, restricciones, verbose):
                    if forward_check(valores_copia, restricciones):
                        return True
            valores[variable] = dominio_original

        return False
    if verbose:
      print("[INFO] Iniciando forward checking...")

    forward_check(valores, restricciones)
    return soluciones

# funcion main que utiliza las funciones dadas
def main():
    valores = inicializar_valores()
    restricciones = crear_restricciones()
    verbose = True
    if not cargar_tablero(valores, "SD9LYSPV"):
        print("Error: El archivo del tablero no se encontró.")
        exit(1)

    if verbose:
      print("Tablero encontrado.")

    aplicar_restricciones(valores, restricciones, verbose)
    soluciones = forward_checking(valores, restricciones, verbose)
    if soluciones:
        for solucion in soluciones:
            imprimir_tablero(solucion)
    else:
        print("No solution exists")

if __name__ == "__main__":
    main()